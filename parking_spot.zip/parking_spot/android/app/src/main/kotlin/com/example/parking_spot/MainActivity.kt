package com.example.parking_spot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

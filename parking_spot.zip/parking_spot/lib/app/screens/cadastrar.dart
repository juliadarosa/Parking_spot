import 'package:flutter/material.dart';

class cadastrar extends StatefulWidget {
  const cadastrar({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<cadastrar> createState() => _cadastrarState();
}

class _cadastrarState extends State<cadastrar> {
  List<double> _ListaItens = [];

  void atualizarResultado(String operation) {
    setState(() {
      _ListaItens.add(1);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.cyanAccent,
        appBar: AppBar(
          title: Text(widget.title),
        ),

        body: Center(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    itemCount: _ListaItens.length,
                    itemBuilder: (context, index) {
                      return  ListTile(
                        title: Text(_ListaItens[0].toString()),
                      );
                    },
                  )
                ]
            )
        )
    );
  }
}